<script>
export default {};
</script>

<template>
  <svg xmlns="http://www.w3.org/2000/svg" width="36" height="12">
    <g fill="#fff">
      <path d="M0 0h36v2H0zM0 10h36v2H0z" />
    </g>
  </svg>
</template>
