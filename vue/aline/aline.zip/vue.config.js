module.exports = {
  runtimeCompiler: true,

  css: {
    sourceMap: true
  },

  lintOnSave: false
}